"use client";

import { useState, useTransition } from "react";
import { Loader2, Pencil } from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { updateTaskTemplateItemAction } from "./_actions";
import type { PositionLite } from "./add-item-dialog";

const SELECT_CLASS =
  "flex h-10 w-full rounded-lg border border-input bg-input px-3 text-sm text-foreground transition-colors outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 dark:bg-input dark:text-foreground";

const PRIORITY_KEYS = ["low", "medium", "high", "urgent"] as const;

const PRIORITY_LABELS: Record<(typeof PRIORITY_KEYS)[number], string> = {
  low: "منخفضة",
  medium: "متوسطة",
  high: "عالية",
  urgent: "عاجلة",
};

// The 8-stage Sky Light workflow — each phase can carry its own responsible
// role, copied onto every task generated from this template item.
const STAGES: {
  key: string;
  label: string;
  badgeTone: string;
  rowTone: string;
}[] = [
  {
    key: "new",
    label: "جديدة",
    badgeTone: "border-slate-300 bg-slate-100 text-slate-700",
    rowTone: "border-slate-200 bg-slate-50/80",
  },
  {
    key: "in_progress",
    label: "قيد التنفيذ",
    badgeTone: "border-sky-300 bg-sky-100 text-sky-700",
    rowTone: "border-sky-200 bg-sky-50/80",
  },
  {
    key: "manager_review",
    label: "مراجعة المدير",
    badgeTone: "border-violet-300 bg-violet-100 text-violet-700",
    rowTone: "border-violet-200 bg-violet-50/80",
  },
  {
    key: "specialist_review",
    label: "مراجعة المتخصص",
    badgeTone: "border-amber-300 bg-amber-100 text-amber-700",
    rowTone: "border-amber-200 bg-amber-50/80",
  },
  {
    key: "ready_to_send",
    label: "جاهزة للإرسال",
    badgeTone: "border-teal-300 bg-teal-100 text-teal-700",
    rowTone: "border-teal-200 bg-teal-50/80",
  },
  {
    key: "sent_to_client",
    label: "أرسلت للعميل",
    badgeTone: "border-indigo-300 bg-indigo-100 text-indigo-700",
    rowTone: "border-indigo-200 bg-indigo-50/80",
  },
  {
    key: "client_changes",
    label: "تعديلات العميل",
    badgeTone: "border-rose-300 bg-rose-100 text-rose-700",
    rowTone: "border-rose-200 bg-rose-50/80",
  },
  {
    key: "done",
    label: "مكتملة",
    badgeTone: "border-emerald-300 bg-emerald-100 text-emerald-700",
    rowTone: "border-emerald-200 bg-emerald-50/80",
  },
];

type DepartmentOpt = { id: string; name: string };

export type EditableTemplateItem = {
  id: string;
  title: string;
  description: string | null;
  default_role_key: string | null;
  default_department_id: string | null;
  offset_days_from_project_start: number;
  duration_days: number;
  upload_offset_days_before_deadline: number | null;
  priority: (typeof PRIORITY_KEYS)[number];
  stage_owner_positions: Record<string, string | null> | null;
  stage_sla_overrides: Record<string, number | null> | null;
};

// Org-default SLAs (working minutes) shown as placeholders. New/In Progress
// have no org default → set per task here. Keep in sync with sla_rules seed (0147).
const DEFAULT_SLA_MINUTES: Record<string, number | null> = {
  new: null,
  in_progress: null,
  manager_review: 90,
  specialist_review: 90,
  ready_to_send: 60,
  sent_to_client: 240,
  client_changes: 480,
  done: null,
};

// #10: edit an existing template item in place — Rwasem's project.category
// task tree is editable; ours was add/delete-only.
export function EditTemplateItemDialog({
  item,
  departments,
  positions,
}: {
  item: EditableTemplateItem;
  departments: DepartmentOpt[];
  positions: PositionLite[];
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  const [title, setTitle] = useState(item.title);
  const [description, setDescription] = useState(item.description ?? "");
  const [role, setRole] = useState<string>(item.default_role_key ?? "");
  const [departmentId, setDepartmentId] = useState<string>(
    item.default_department_id ?? "",
  );
  const [offset, setOffset] = useState<string>(
    String(item.offset_days_from_project_start),
  );
  const [duration, setDuration] = useState<string>(String(item.duration_days));
  const [uploadOffset, setUploadOffset] = useState<string>(
    item.upload_offset_days_before_deadline == null
      ? ""
      : String(item.upload_offset_days_before_deadline),
  );
  const [priority, setPriority] = useState<(typeof PRIORITY_KEYS)[number]>(
    item.priority,
  );
  const seedStageOwners = () => {
    const seed = item.stage_owner_positions ?? {};
    const out: Record<string, string> = {};
    for (const s of STAGES) out[s.key] = (seed[s.key] as string | null) ?? "";
    return out;
  };
  const [stageOwners, setStageOwners] = useState<Record<string, string>>(
    seedStageOwners,
  );
  const seedStageSla = () => {
    const seed = item.stage_sla_overrides ?? {};
    const out: Record<string, string> = {};
    for (const s of STAGES) {
      const v = seed[s.key];
      out[s.key] = v == null ? "" : String(v);
    }
    return out;
  };
  const [stageSla, setStageSla] = useState<Record<string, string>>(seedStageSla);

  // Re-sync local state to the row whenever the dialog is (re)opened so a
  // stale edit from a prior cancel never lingers.
  const resetToItem = () => {
    setTitle(item.title);
    setDescription(item.description ?? "");
    setRole(item.default_role_key ?? "");
    setDepartmentId(item.default_department_id ?? "");
    setOffset(String(item.offset_days_from_project_start));
    setDuration(String(item.duration_days));
    setUploadOffset(
      item.upload_offset_days_before_deadline == null
        ? ""
        : String(item.upload_offset_days_before_deadline),
    );
    setPriority(item.priority);
    setStageOwners(seedStageOwners());
    setStageSla(seedStageSla());
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    start(async () => {
      if (title.trim().length < 2) {
        toast.error("اكتب عنوان المهمة");
        return;
      }
      const res = await updateTaskTemplateItemAction({
        itemId: item.id,
        title: title.trim(),
        description: description.trim() || null,
        default_role_key:
          role && positions.some((p) => p.slug === role) ? role : null,
        default_department_id: departmentId || null,
        offset_days_from_project_start: Number(offset) || 0,
        duration_days: Math.max(0, Number(duration) || 0),
        upload_offset_days_before_deadline:
          uploadOffset.trim() === "" ? null : Math.max(0, Number(uploadOffset) || 0),
        priority,
        stage_owner_positions: Object.fromEntries(
          STAGES.map((s) => [s.key, stageOwners[s.key] || null]),
        ),
        stage_sla_overrides: Object.fromEntries(
          STAGES.map((s) => {
            const raw = (stageSla[s.key] ?? "").trim();
            const n = raw === "" ? null : Math.max(0, Math.round(Number(raw)));
            return [s.key, Number.isFinite(n as number) ? n : null];
          }),
        ),
      });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      toast.success("حُدّثت مهمة القالب");
      setOpen(false);
      router.refresh();
    });
  };

  return (
    <>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => {
          resetToItem();
          setOpen(true);
        }}
        aria-label={`تعديل ${item.title}`}
      >
        <Pencil className="size-3.5" />
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>تعديل مهمة القالب</DialogTitle>
            <DialogDescription>
              تُطبَّق التعديلات على المشاريع الجديدة التي تُنشأ من هذا القالب.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={onSubmit} className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="edit_item_title">عنوان المهمة *</Label>
              <Input
                id="edit_item_title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                maxLength={200}
                disabled={pending}
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="edit_item_description">الوصف</Label>
              <Textarea
                id="edit_item_description"
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                disabled={pending}
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="edit_item_dept">القسم المسؤول</Label>
                <select
                  id="edit_item_dept"
                  className={SELECT_CLASS}
                  value={departmentId}
                  onChange={(e) => setDepartmentId(e.target.value)}
                  disabled={pending}
                >
                  <option value="">— بدون —</option>
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="edit_item_role">الدور المسؤول</Label>
                <select
                  id="edit_item_role"
                  className={SELECT_CLASS}
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  disabled={pending}
                >
                  <option value="">— بدون —</option>
                  {positions.map((p) => (
                    <option key={p.slug} value={p.slug}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              <div className="space-y-1.5">
                <Label htmlFor="edit_item_offset">
                  الإزاحة من بداية المشروع (يوم)
                </Label>
                <Input
                  id="edit_item_offset"
                  type="number"
                  min={0}
                  value={offset}
                  onChange={(e) => setOffset(e.target.value)}
                  disabled={pending}
                  dir="ltr"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="edit_item_duration">المدة (يوم)</Label>
                <Input
                  id="edit_item_duration"
                  type="number"
                  min={0}
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  disabled={pending}
                  dir="ltr"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="edit_item_priority">الأولوية</Label>
                <select
                  id="edit_item_priority"
                  className={SELECT_CLASS}
                  value={priority}
                  onChange={(e) =>
                    setPriority(e.target.value as (typeof PRIORITY_KEYS)[number])
                  }
                  disabled={pending}
                >
                  {PRIORITY_KEYS.map((p) => (
                    <option key={p} value={p}>
                      {PRIORITY_LABELS[p]}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="edit_item_upload_offset">موعد الرفع — أيام قبل الموعد النهائي</Label>
              <Input
                id="edit_item_upload_offset"
                type="number"
                min={0}
                value={uploadOffset}
                onChange={(e) => setUploadOffset(e.target.value)}
                disabled={pending}
                dir="ltr"
                placeholder="بدون موعد رفع"
              />
              <p className="text-[11px] text-muted-foreground">
                عند تعبئته، تُنشأ المهمة بموعد رفع = الموعد النهائي ناقص هذا العدد، فتظهر في «رفع المهام». اتركه فارغًا للمهام التي لا تتطلب رفعًا.
              </p>
            </div>
            <div className="space-y-1.5 rounded-lg border border-soft bg-soft-1/40 p-3">
              <Label>الدور المسؤول و SLA لكل مرحلة</Label>
              <p className="text-[11px] text-muted-foreground">
                يُحدَّد لكل مرحلة الدور المسؤول و مدة الـ SLA (بالدقائق، وقت عمل
                فقط). القيم القياسية معبّأة مسبقًا — اتركها فارغة لاستخدام
                الافتراضي. مرحلتا «جديدة» و«قيد التنفيذ» تُحدَّد لكل مهمة هنا.
              </p>
              <div className="mt-2 grid gap-2 sm:grid-cols-2">
                {STAGES.map((s) => (
                  <div
                    key={s.key}
                    className={`grid grid-cols-[minmax(0,1fr)_7.5rem_5rem] items-center gap-2 rounded-xl border p-2 ${s.rowTone}`}
                  >
                    <span
                      className={`inline-flex min-w-0 items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold text-start ${s.badgeTone}`}
                    >
                      {s.label}
                    </span>
                    <select
                      className={SELECT_CLASS + " h-9 w-full"}
                      value={stageOwners[s.key] ?? ""}
                      onChange={(e) =>
                        setStageOwners((m) => ({
                          ...m,
                          [s.key]: e.target.value,
                        }))
                      }
                      disabled={pending}
                      aria-label={`الدور المسؤول عن مرحلة ${s.label}`}
                    >
                      <option value="">— بدون —</option>
                      {positions.map((p) => (
                        <option key={p.slug} value={p.slug}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                    <Input
                      type="number"
                      min={0}
                      dir="ltr"
                      className="h-9 w-full"
                      value={stageSla[s.key] ?? ""}
                      placeholder={
                        DEFAULT_SLA_MINUTES[s.key] != null
                          ? `${DEFAULT_SLA_MINUTES[s.key]}د`
                          : "—"
                      }
                      onChange={(e) =>
                        setStageSla((m) => ({ ...m, [s.key]: e.target.value }))
                      }
                      disabled={pending}
                      aria-label={`SLA لمرحلة ${s.label} بالدقائق`}
                    />
                  </div>
                ))}
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setOpen(false)}
                disabled={pending}
              >
                إلغاء
              </Button>
              <Button type="submit" disabled={pending}>
                {pending && <Loader2 className="size-4 animate-spin" />}
                حفظ التعديلات
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
